<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); ?>

<?php echo "Hello " . $_SESSION['username']; ?>

<a href="/logout.php">Logout</a>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>
