<?php 
$page_title = "More About You";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 
?>

<p> <b>Sharing your goals provides more accountability--a great way to keep on track. </p>
<p>Supporting a cause gives you added motivation, and becomes a reward in and of itself.</p>
<p>So join the Lose-A-Thon!  Reach out to your Facebook Friends, and get them to pledge $1/pound if you reach your pounds lost goal. All proceeds go to Feed the Children. </p></b>
</br>
<p> <font size="+2"> When you lose, hungry kids win!</p> </font>



<input name="Join" type="button" value="Join" />
