<?php 
$page_title = "Health Goals";
$show_tags = "goal";
	
require_once($_SERVER['DOCUMENT_ROOT'] . "/core/header.inc.php"); ?>

<?php
  	include_once($_SERVER['DOCUMENT_ROOT'] . '/core/goals.inc.php'); 
	
  	$agoal = get_user_goal($_GET['fb_user_id'], $_GET['goal_id']); 
	//print_r($agoal);
	
	if(!empty($agoal))
	{
	?>
	  <h2><?php $fb_user = get_fb_user($_GET['fb_user_id']); echo $fb_user['user_fname']; ?>'s Health Goal</h2>
	  <div id="goal_box">
		<div id="goad_icon">
		  <img src="<?php echo $agoal['goal_icon_url']; ?>" />
		</div>
		<div id="goal_title">
		  <p><?php echo $agoal['goal_string']; ?></p>
		</div>
		<div id="goal_desc">
		  <p><?php echo (empty($agoal['goal_total'])) ? "" : (($agoal['goal_finished'] / $agoal['goal_total']) * 100) . "% complete"; ?></p>
		</div>
	  </div>
	  <h2>Charity Info</h2>
	  <p>Pledge to ___ charity. Donate $ __ for every pound <?php echo $fb_user['user_fname']; ?> loses! Everybody wins! </p>
	<?php
	}
	else
	{
	?>
	
	<div id="goal_box">
	  <p>No Goal found!</p>
	</div>
	
	<?php
	}
  ?>
  <?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/footer.inc.php"); ?>
