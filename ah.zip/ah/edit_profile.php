<?php 
$page_title = "Update Profile";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 
$afbuser = get_fb_user($fbuser);
if(isset($_POST['posted']))
{
    $errors = array();
	if(empty($errors))
	{
		update_user (
					$_POST['firstname'], 
					$_POST['lastname'], 
					$_POST['zip'], 
					$_POST['gender'], 
					$_POST['email'], 
					$_POST['dob'],
					$fbuser);
		 echo '<p>Your account has been updated.</p><p>Click <a href="/profile.php">here</a> to go to your profile.</p>';
		 $afbuser = get_fb_user($fbuser);

	 }
}
?>
<h1> Update Profile </h1>
<form action="" method="post">
  <p><label for="firstname">First Name</label>
    <input type="text" name="firstname" id="firstname" value="<?php echo $afbuser['user_fname']; ?>">
  </p>
  <p><label for="lastname">Lastname</label>
    <input type="text" name="lastname" id="lastname" value="<?php echo $afbuser['user_lname']; ?>">
  </p>
  <p>
    <label for="zip">Zip</label>
    <input type="text" name="zip" id="zip" value="<?php echo $afbuser['user_zip']; ?>">
  </p>
  <p>
    <label for="gender">Gender</label>
    <select name="gender">
      <option value="F" <?php if ($afbuser['user_gender'] === 'F') echo 'Selected'; ?>>Female</option>
      <option value="M" <?php if ($afbuser['user_gender'] === 'M') echo 'Selected'; ?>>Male</option>
      <option value="X" <?php if ($afbuser['user_gender'] === 'X') echo 'Selected'; ?>>Undisclosed</option>	
	</select>
  </p>
  <p>
    <label for="email">Email</label>
    <input type="text" name="email" id="email" value="<?php echo $afbuser['user_email']; ?>">
  </p>
  <p><label for="dob">Date of Birth</label>  
    <input type="text" name="dob" id="dob" value="<?php echo date('m/d/Y', strtotime($afbuser['user_dob'])); ?>">
    <input type="hidden" name="posted">
  </p>
  <p>
    <input type="submit" name="Submit" value="Submit" id="Submit">
  </p>
</form>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>