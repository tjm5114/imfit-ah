<?php 
$page_title = "Register";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 

if(!$fbuser)
{
	echo "<p> You are not logged in via Facebook.</p>";
}

$fb_user_exists = facebook_user_exists($fbuser);

if($fb_user_exists)
{
	echo '<p> You have already registered. Click <a href="/profile.php">here</a> to go to your profile.</p>';
}

if(isset($_POST['posted']) && !$fb_user_exists)
{
	$errors = array();
	
	if(empty($_POST['email']))
	{
		$errors[] = 'The email cannot be empty.';
	}

	if(empty($errors))
	{
		add_user(
			$fbuser, 
			$_POST['firstname'], 
			$_POST['lastname'], 
			$_POST['zip'], 
			$_POST['gender'], 
			$_POST['email'], 
			null, 
			$_POST['age'], 
			$_POST['dob'], 
			$fbuser, 
			null);
		echo "Your account has been created.<br>";
		
		//$_SESSION['fbuser'] = htmlentities($fbuser);
		
		//header('Location: /create_goals.php');
		//die();
	}
}

?>
		<?php
		if(empty($errors) == false)
		{
			?>
			<ul id="errors">
			
			<?php
			foreach($errors as $error) 
			{
				echo "<li>$error</li>";
			}
			?>
			
			</ul>
			
			<?php
		}
//print_r ($fb_user_info);
	?>

<?php if($fbuser && !$fb_user_exists) { ?>
<form action="" method="post">
  <p><label for="firstname">First Name</label>
  
    <input type="text" name="firstname" id="firstname" value="<?php echo $fb_user_info['first_name']; ?>">
  </p>
  <p><label for="lastname">Lastname</label>
  
    <input type="text" name="lastname" id="lastname" value="<?php echo $fb_user_info['last_name']; ?>">
  </p>
  <p>
    <label for="zip">Zip</label>
    <input type="text" name="zip" id="zip">
  </p>
  <p>
    <label for="gender">Gender</label>
    <select name="gender">
      <option value="F" <?php if ($fb_user_info['gender'] === 'female') echo 'Selected'; ?>>Female</option>
      <option value="M" <?php if ($fb_user_info['gender'] === 'male') echo 'Selected'; ?>>Male</option>
      <option value="X" <?php if ($fb_user_info['gender'] != 'male' && $fb_user_info['gender'] != 'female') echo 'Selected'; ?>>Undisclosed</option>
	
	</select>
  </p>
  <p>
    <label for="email">Email</label>
    <input type="text" name="email" id="email" value="<?php echo $fb_user_info['email']; ?>">
  </p>
  <p><label for="dob">Date of Birth</label>  
    <input type="text" name="dob" id="dob" value="<?php echo $fb_user_info['birthday']; ?>">
    <input type="hidden" name="posted">
  </p>
  <p>
    <input type="submit" name="Submit" value="Submit" id="Submit">
  </p>
</form>
<?php } ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>
