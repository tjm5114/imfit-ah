<?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/header.inc.php"); ?>

<?php
if(isset($_POST['username'], $_POST['password'], $_POST['validate_password']))
{
	if(empty($_POST['username']))
	{
		$errors[] = 'The username cannot be empty.';
	}
	if(empty($_POST['password']) || empty($_POST['validate_password']))
	{
		$errors[] = 'The password cannot be empty.';
	}
	if($_POST['password'] !== $_POST['validate_password'])
	{
		$errors[] = 'Password verification failed.';
	}
	if(empty($_POST['firstname']))
	{
		$errors[] = 'The first name cannot be empty.';
	}
	if(empty($_POST['email']))
	{
		$errors[] = 'The email cannot be empty.';
	}

	/*if(user_exists($_POST['username']))
	{
		$errors[] = 'The username you entered is already taken.';
	}*/
	
	if(empty($errors))
	{
		add_user($_POST['username'], $_POST['zip'], $_POST['gender'], $_POST['email'], $_POST['password'], null, null, null, null);
		echo "done adding user <br>";
		
		$_SESSION['username'] = htmlentities($_POST['username']);
		
		header('Location: /protected.php');
		//die();
	}
}

?>
		<?php
		if(empty($errors) == false)
		{
			?>
			<ul id="errors">
			
			<?php
			foreach($errors as $error) 
			{
				echo "<li>$error</li>";
			}
			?>
			
			</ul>
			
			<?php
		}
	?>

<form action="" method="post">
  <p><label for="username">Username</label>  
    <input type="text" name="username" id="username">
  </p>
  <p><label for="password">Password</label>  
    <input type="password" name="password" id="password">
  </p>
  <p><label for="validate_password">Validate Password</label>  
    <input type="password" name="validate_password" id="validate_password">
  </p>
  <p><label for="firstname">First Name</label>
  
    <input type="text" name="firstname" id="firstname">
  </p>
  <p><label for="lastname">Lastname</label>
  
    <input type="text" name="lastname" id="lastname">
  </p>
  <p>
    <label for="zip">Zip</label>
    <input type="text" name="zip" id="zip">
  </p>
  <p>
    <label for="gender">Gender</label>
    <select name="gender">
      <option value="F" selected>Female</option>
      <option value="M">Male</option>
      <option value="X">Undisclosed</option>
	
	</select>
  </p>
  <p>
    <label for="email">Email</label>
    <input type="text" name="email" id="email">
  </p>
  <p><label for="dob">Date of Birth</label>  
    <input type="text" name="dob" id="dob">
  </p>
  <p>
    <input type="submit" name="Submit" value="Submit" id="Submit">
  </p>
</form>

<?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/footer.inc.php"); ?>

