<?php 
$page_title = "More About You";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 
?>

<?php

if (isset($_POST['submit']) )
{
	$auser = get_fb_user($fbuser);
	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '1', null, '" . $_POST['answer1'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '2', null, '" . $_POST['answer2'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '3', null, '" . $_POST['answer3'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '3', null, '" . $_POST['answer4'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '3', null, '" . $_POST['answer5'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '4', null, '" . $_POST['answer6'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '4', null, '" . $_POST['answer7'] . "')";
	
	//echo $sql;
	mysql_query($sql);

	$sql = "insert into user_response (user_id, q_id, q_string, ans_string) values ('" . $auser['user_id'] . "', '4', null, '" . $_POST['answer8'] . "')";
	
	//echo $sql;
	mysql_query($sql);
	
	echo '<p>Thanks! Click <a href="/loseathon.php">Next</a>  to continue.';
} 

else
{

?>

<div style="width:500">
<form action="" method="post">

  <p>Congratulations on completing the all important first step... setting goals and committing to change!  The next step is to think deeply about what you really want out of life- the inner motivation driving your goals, such as:  </p>
  <ul>
    <li>I really want to be a better role model for my family. I want my kids to be proud of me.      </li>
    <li>I really want to avoid becoming diabetic. I want to take charge of my health, and enjoy a better quality of life.</li>
    <li> I really don't want to let my Facebook friends down. They are supporting me as I transform my life, so my pride is on the line.  Plus I really, really want to help the kids through the Lose-A-Thon. </li>
  </ul>
  <p>
    <label for="textarea"></label>
    <textarea name="answer1" cols="50" rows="5" id="answer1"></textarea>
  </p>
  <hr />
  <p>Transformation is powerful.  How do you envision yourself if you accomplish your goals, and obtain what you really want?  Examples would be:</p>
  <ul>
    <li>I'll look great in a bikini!      </li>
    <li>I'll have great mobility now that I'm no longer lugging around 50 excess pounds!      </li>
    <li>My dating life will really pickup!
      It's great to be in shape: goodbye blood medication and their side-effects!      </li>
  </ul>
  <p>
    <textarea name="answer2" cols="50" rows="5" id="answer2"></textarea>
  </p>
  <hr />
  <p> When we�re busy, distracted, multi-tasking, stressed and/or tired, self-aware thinking gets crowded out and we function on routines or habits that we could do in our sleep. Identify bad habits that undermine your progress, so you can develop strategies to change these habits.</p>
  <p> Examples are:</p>
  <ul>
    <li> Mindless eating while watching TV. When my favorite show comes on, almost without thinking, I grab a bag of chips and before I realize I've eaten half the bag.      </li>
    <li>I shop when I'm hungry.  When I get to the checkout, there is way to much junk food in my cart.      </li>
    <li>When I'm feeling down, I reward myself with junk.</li>
  </ul>
  <p>
    <label for="answer3"></label>
    <input name="answer3" type="text" id="answer3" size="50">
</p>
  <p>
    <input name="answer4" type="text" id="answer4" size="50">
</p>
  <p>
    <input name="answer5" type="text" id="answer5" size="50">
</p>
 <hr />
 <p>Now, think how you can convert those bad habits into good habits, or develop new good habits</p>
 <p>Examples are:   </p>
 <ul>
   <li>Tweak mindless eating while watching TV routine. When my favorite show comes on, I'll grab a calorie free beverage.     </li>
   <li>I'll do my food planning for the week Sunday afternoon, and make sure I have healthy foods around all week.     </li>
   <li>When I'm feeling down, I'll reward myself with a walk, or song or call a freind. </li>
  </ul>
 <p>
   <input name="answer6" type="text" id="answer6" size="50">
</p>
 <p>
   <input name="answer7" type="text" id="answer7" size="50">
 </p>
 <p>
   <input name="answer8" type="text" id="answer8" size="50">
 </p>
<hr /> <p>
   <input type="submit" name="submit" value="Submit" id="Submit">
 </p>
</form>
</div>

<?php 
}
?>

<?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/footer.inc.php"); ?>
