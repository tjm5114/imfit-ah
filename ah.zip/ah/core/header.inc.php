<?php 
require_once($_SERVER['DOCUMENT_ROOT'] . "/core/init.inc.php"); 

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US"
      xmlns:fb="https://www.facebook.com/2008/fbml">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# imfitdemo: http://ogp.me/ns/fb/imfitdemo#">
  <!-- Facebook "Goal" object specific tags -->
<?php	

if($show_tags === 'goal')
{
	include_once($_SERVER['DOCUMENT_ROOT'] . '/core/goals.inc.php'); 
	$agoal = get_user_goal($_GET['fb_user_id'], $_GET['goal_id']); 
	
	if(!empty($agoal)) 
	{ 

?>
  <meta property="fb:app_id" content="271768606264231" /> 
  <meta property="og:type"   content="imfitdemo:goal" /> 
  <meta property="og:url"    content="<?php echo $_SERVER['HTTPS'] ? "https" : "http" . "://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']; ?>" /> 
  <meta property="og:title"  content="<?php echo $agoal['goal_string']; ?>" /> 
  <meta property="og:image"  content="<?php echo $agoal['goal_icon_url']; ?>" /> 
<?php
	}
}
?>
  <!-- Done Facebook "Goal" object specific tags -->
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  
		<link rel="stylesheet" href="/style.css" type="text/css" />

	<link rel="icon" 
		  type="image/png" 
		  href="/favicon.png">

 <title><?php echo $page_title; ?></title>

 <script type="text/javascript" src="/javascript/jquery-1.7.1.min.js"></script>

    <script type="text/javascript">
      function logResponse(response) {
        if (console && console.log) {
          console.log('The response was', response);
        }
      }

      $(function(){
        // Set up so we handle click on the buttons
        $('#postToWall').click(function() {
          FB.ui(
            {
              method : 'feed',
              link   : $(this).attr('data-url')
            },
            function (response) {
              // If response is null the user canceled the dialog
              if (response != null) {
                logResponse(response);
              }
            }
          );
        });

        $('#sendToFriends').click(function() {
          FB.ui(
            {
              method : 'send',
              link   : $(this).attr('data-url')
            },
            function (response) {
              // If response is null the user canceled the dialog
              if (response != null) {
                logResponse(response);
              }
            }
          );
        });

        $('#sendRequest').click(function() {
          FB.ui(
            {
              method  : 'apprequests',
              message : $(this).attr('data-message')
            },
            function (response) {
              // If response is null the user canceled the dialog
              if (response != null) {
                logResponse(response);
              }
            }
          );
        });
      });
    </script>
	    <!--[if IE]>
      <script type="text/javascript">
        var tags = ['header', 'section'];
        while(tags.length)
          document.createElement(tags.pop());
      </script>
    <![endif]-->
</head>

<body>
  	<ul class="top">
		<li><a href="/">Home</a> | About | FAQ | 
      <?php 
	  	if(!$fbuser)
		{
		?>
	        <div class="fb-login-button" data-scope="user_likes,user_photos,user_birthday,email,publish_actions"> </div> 
      <?php  
	  	} 
		else 
		{ 
		?>
		<a href="profile.php"><?php 
	  		echo $fb_user_info['name'] ; ?>
		</a> (<a href="/logout.php">logout</a>)
		<?php
		} ?></li>
	</ul>	
	
	<div class="outer">
		<div class="intro">
			<!--<center>-->
			<table align="center">
			<tr>
			<td><img class="logo" src="logo-small4.jpg" /></td>
			<td><font class="intro"><?php echo $page_heading; ?></font></td>
			</tr>
			</table>
			<!--</center>-->
		</div>	
	</div>

<div id="fb-root"></div>
    <script type="text/javascript">
      window.fbAsyncInit = function() {
        FB.init({
          appId      : '<?php echo $app_id; ?>', // App ID
          //channelUrl : '//<?php //echo $_SERVER["HTTP_HOST"]; ?>/channel.html', // Channel File
          status     : true, // check login status
          cookie     : true, // enable cookies to allow the server to access the session
          xfbml      : true // parse XFBML
        });

        // Listen to the auth.login which will be called when the user logs in
        // using the Login button
        FB.Event.subscribe('auth.login', function(response) {
          // We want to reload the page now so PHP can read the cookie that the
          // Javascript SDK sat. But we don't want to use
          // window.location.reload() because if this is in a canvas there was a
          // post made to this page and a reload will trigger a message to the
          // user asking if they want to send data again.
          window.location = window.location;
        });

        FB.Canvas.setAutoGrow();
      };

      // Load the SDK Asynchronously
      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/all.js";
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>


		<div class="fb-login-button" data-scope="user_likes,user_photos,user_birthday,email,publish_actions" data-show-faces="true" data-width="200" data-max-rows="1"></div>

	
	
	
	
	
	
	
	
	
	
	
	

