<?php

// get a goal given its ID
function get_goal($goal_id)
{
	//$garray = array();
	$sql = "select * from goal where goal_id = '$goal_id'";
	$goal = mysql_query($sql);
	
	if ($goal)
	{
		$garray = mysql_fetch_assoc($goal);
	}
	return $garray;
}


// adds a goal to the database
function add_goal($user_string, $goal_metric, $goal_icon_url)
{

	$sql ="insert into goal (goal_string, goal_metric, goal_icon_url)
			values ('$goal_string', '$goal_metric', '$goal_icon_url')";
		//echo "$sql ";
	
	mysql_query($sql);
}

function get_user_goals($fbuser)
{
	$sql = "SELECT a.*, c.goal_icon_url FROM user_goals a, users b, goal c
	where a.user_id = b.user_id 
	and a.goal_id = c.goal_id
	and b.user_fb_id = '$fbuser'";

	$result = mysql_query($sql);

	$agoals = array();

	while ($agoal = mysql_fetch_assoc($result)) 
	{
		$agoals[] = $agoal;
	}
	return $agoals;
}

function get_all_goals($fbuser)
{
	$sql = "select g.* , uug.goal_active
from goal g left outer join 
(select ug.goal_id, 'Y' goal_active
from user_goals ug, users u
where ug.user_id = u.user_id
and u.user_fb_id = '$fbuser') uug
on g.goal_id = uug.goal_id";
	$result = mysql_query($sql);

	$agoals = array();

	while ($agoal = mysql_fetch_assoc($result)) 
	{
		$agoals[] = $agoal;
	}
	return $agoals;
	
}

function get_user_goal($user_fb_id, $goal_id)
{
	$sql = "SELECT a.*, c.goal_icon_url FROM user_goals a, users b, goal c
	where a.user_id = b.user_id 
	and a.goal_id = c.goal_id
	and b.user_fb_id = '$user_fb_id'
	and c.goal_id = '$goal_id'";
	
//	echo $sql;
	$goal = mysql_query($sql);

	if($goal)
	{
		$agoal = mysql_fetch_assoc($goal); 
	}
	//print_r( $agoal);
	return $agoal;
}

function add_user_goal($goal_id, $user_fb_id, $goal_total, $goal_finished)
{
		$sql ="insert into user_goals (user_id, goal_id, goal_string, goal_total, goal_finished, date_goal_created)
			 (select u.user_id, '$goal_id', g.goal_string, '$goal_total', null, now() from users u, goal g
			 where u.user_fb_id = '$user_fb_id' and g.goal_id = '$goal_id')";
		//echo "$sql ";
	
	mysql_query($sql);

}

?>