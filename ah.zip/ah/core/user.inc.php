<?php

// checks if the given username exists in the table
function user_exists($user_name)
{
	$user_name = mysql_real_escape_string($user_name);
	$sql = "select count(*) from users where user_name = '$user_name'";
	$total = mysql_query($sql);
	return (mysql_result($total, 0) == '1') ? true : false;
}

// checks if the given facebook user exists in the table
function facebook_user_exists($user_fb_id)
{
	$user_fb_id = mysql_real_escape_string($user_fb_id);
	$sql = "select count(*) from users where user_fb_id = '$user_fb_id'";
	$total = mysql_query($sql);
	//echo "facebook_user_exists = " . mysql_result($total, 0);
	return (mysql_result($total, 0) == '1') ? true : false;
}

// checks if the given username and password combination is valid
function valid_credentials($user_name, $user_password)
{
	$user_name= mysql_real_escape_string($user_name);
	$user_password = sha1($user_password);
	$sql = "select count(*) from users where user_name = '$user_name' and user_password = '$user_password'";
	$total = mysql_query($sql);
	return (mysql_result($total, 0) == '1') ? true : false;
}

// adds a user to the database
function add_user($user_name, $user_fname, $user_lname, $user_zip, $user_gender, $user_email, $user_password, $user_age, $user_dob, $user_fb_id, $user_reg_date)
{
//	$user_name = mysql_real_escape_string(htmlentities($user_name));
//	$user_fname = mysql_real_escape_string(htmlentities($user_fname));
//	$user_lname = mysql_real_escape_string(htmlentities($user_lname));
//	$user_zip = mysql_real_escape_string(htmlentities($user_zip));
//	$user_gender = mysql_real_escape_string(htmlentities($user_gender));
//	$user_email = mysql_real_escape_string(htmlentities($user_email));
	$user_password = sha1($user_password);
//	$user_age = mysql_real_escape_string($user_age);
//	$user_dob = mysql_real_escape_string($birthday);
//	$user_fb_id = mysql_real_escape_string($user_fb_id);

	$sql ="insert into users (user_name, user_fname, user_lname, user_zip, user_gender, user_email, user_password, user_age, user_dob, user_fb_id, user_reg_date) 
			values ('$user_name', '$user_fname', '$user_lname', '$user_zip', '$user_gender', '$user_email', '$user_password', '$user_age', null, '$user_fb_id', null)";
		//echo "$sql ";
	
	mysql_query($sql);
}

function update_user($user_fname, $user_lname, $user_zip, $user_gender, $user_email, $user_dob, $user_fb_id)
{ 
	$sql ="UPDATE users SET
				user_fname= '$user_fname', 
				user_lname= '$user_lname', 
				user_zip  = '$user_zip', 
				user_gender= '$user_gender', 
				user_email= '$user_email', 
				user_dob=str_to_date('$user_dob','%m/%d/%Y')
				WHERE user_fb_id='$user_fb_id'"; 
		//echo "$sql ";
	
	mysql_query($sql);
}
// gets the user details
function get_user($user_name)
{
	$uarray = array();
	
	$user = mysql_query("select * from users where user_name = '$username'");
	
	if ($user)
	{
		$uarray = mysql_fetch_row($user);
	}
	return $uarray;
}

function get_fb_user($user_fb_id)
{
	$uarray = array();
	//echo "<p>Getting fbuser $fbuser</p>";
	$user = mysql_query("select * from users where user_fb_id = '$user_fb_id'");
	
	if ($user)
	{
		$uarray = mysql_fetch_assoc($user);
	}
	//var_dump ($uarray);
	return $uarray;
}
?>
