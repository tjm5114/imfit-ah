<?php

//session_start();
include_once "fbconnect.inc.php";
//echo "blah";
include_once($_SERVER['DOCUMENT_ROOT'] . "/core/user.inc.php");
//echo "blah";
include_once($_SERVER['DOCUMENT_ROOT'] . "/core/dbconnect.inc.php");


$exceptions = array('index', 'register', 'login', 'create_goal', 'show_user_goal');


$page = substr(end(explode('/', $_SERVER['SCRIPT_NAME'])), 0, -4);

if(in_array($page, $exceptions) === false)
{
//	if(isset($_SESSION['fbuserid']) === false)
	if(!$fbuser)
	{
		header('Location: /index.php');
		die();
	}
	else
	{
		if(!facebook_user_exists($fbuser) && $page != 'register')
		{	
			//echo "logged in but not registered";
			// user is logged in but not registered with our database
			header('Location: /register.php');
			die();
		}
	}
}
?>