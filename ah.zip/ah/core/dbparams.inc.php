<?php

// DB connection info
/*$host = "tcp:k6lyow7xf5.database.windows.net,1433";
$user = "imfitdbadmin@k6lyow7xf5";
$pwd = "Imfit12!";
$db = "imfitdb";
*/

$host = 'localhost';
$user = 'imfitcom_ahuser';
$pwd = 'imfitcom_ahuser';
$db = 'imfitcom_ah';

?>