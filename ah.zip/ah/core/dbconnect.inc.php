<?php

require_once($_SERVER['DOCUMENT_ROOT'] . "/core/dbparams.inc.php");

//$conn = null;

try
{
//    $conn = new PDO( "sqlsrv:Server= $host ; Database = $db ", $user, $pwd);
//    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
//	var_dump($conn);
	mysql_connect($host, $user, $pwd);
	@mysql_select_db($db) or die( "Unable to select database");

}
catch(Exception $e)
{
	//$conn = null;
    //die(var_dump($e));
}

?>