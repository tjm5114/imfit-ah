<?php

$app_id		= "271768606264231";
$app_secret	= "c44cac184086822fec709f9dec9e0aa7";
$site_url	= "http://imfitah.azurewebsites.net/";

require_once "php-sdk/src/facebook.php";

$facebook = new Facebook(array(
	'appId'		=> $app_id,
	'secret'	=> $app_secret,
	));
 
$fbuser = $facebook->getUser();

//echo '<p>Checking $fbuser.</p>';
if($fbuser)
{
	//echo '<p>$fbuser = ' . "$fbuser</p>";
//============ Single query method ==============
	try
	{
		// Proceed knowing you have a logged in user who's authenticated
		$user_profile = $facebook->api('/me','GET');
		//echo "<p>Name: " . $user_profile['name'] . "</p>";

	}
	catch(FacebookApiException $e)
	{
		//echo "<p>Caught exception.</p>";
		//error_log($e);
		$fbuser = NULL;
	}
//============ Single query method ends =========
}

if($fbuser)
{
	// Get logout URL
	$logoutUrl = $facebook->getLogoutUrl();
}
else
{
	// Get login URL
	$loginUrl = $facebook->getLoginUrl(array(
		'scope'	=> 'read_stream, publish_stream, user_birthday, user_location, user_birthday, email',
		'redirect_uri' => 'http://testimf.mindlesscreations.com/fb_login.php',
		));
}


if($fbuser)
{
	// Proceed knowing you have a logged in user who has a valid session.
	// Batch requests over the Facebook Graph API using the PHP-SDK
	// Save your method calls into an array

	$queries = array
	(
		array('method' => 'GET', 'relative_url' => '/'.$fbuser),
//		array('method' => 'GET', 'relative_url' => '/'.$fbuser.'/home?limit=50'),
//		array('method' => 'GET', 'relative_url' => '/'.$fbuser.'/friends'),
//		array('method' => 'GET', 'relative_url' => '/'.$fbuser.'/photos?limit=6'),
	);
 
	// POST your queries to the batch endpoint on the graph.
	try
	{
		$batchResponse = $facebook->api('?batch='.json_encode($queries), 'POST');
	}
	catch(Exception $o)
	{
		error_log($o);
	}
 
	//Return values are indexed in order of the original array, content is in ['body'] as a JSON
	//string. Decode for use as a PHP array.
	$fb_user_info		= json_decode($batchResponse[0]['body'], TRUE);
	//$feed			= json_decode($batchResponse[1]['body'], TRUE);
	//$friends_list		= json_decode($batchResponse[2]['body'], TRUE);
	//$photos			= json_decode($batchResponse[3]['body'], TRUE);
	// Batch requests over the Facebook Graph API using the PHP-SDK ends
}


?>
