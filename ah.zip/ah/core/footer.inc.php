	<div class="bottom">

		<img class="bottom social" src="https://imfitah.blob.core.windows.net/logos/facebook.png" />
		<img class="bottom social" src="https://imfitah.blob.core.windows.net/logos/twitter.png" />
		<img class="bottom social" src="https://imfitah.blob.core.windows.net/logos/linkedin.png" />
		<img class="bottom social" src="https://imfitah.blob.core.windows.net/logos/youtube.png" />
		
		<div class="wheremade">
			<font class="bottom intro">Made in Boston at </font><img class="angelhack" src="angelhack.png" /><font class="bottom end"> Summer 2012</font><br>
		</div>
		
		<font class="copyright">Copyright Ashish Kasturia, Trey Morris, Rebecca Sealfon, Dan Sterling, Deepak Vokaliga</font>
		<img class="bottom loseathon" src="https://imfitah.blob.core.windows.net/logos/shield.jpg" />
	</div>
	
	</body>

</html>