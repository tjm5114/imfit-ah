<?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/header.inc.php"); ?>

<?php
  	include_once($_SERVER['DOCUMENT_ROOT'] . '/core/goals.inc.php'); 
  	$agoals = get_all_goals($fbuser); 

	foreach($agoals as $agoal)
	{
	?>
	  <div id="goal_box">
		<div id="goad_icon">
		  <img src="<?php echo $agoal['goal_icon_url']; ?>" />
		</div>
		<div id="goal_title">
		  <p><?php echo $agoal['goal_string']; ?></p>
		</div>
		<div id="goal_desc">
		  <p><?php 
		    if(empty($agoal['goal_active'])) { echo '<a href="?goal_id=' . $agoal['goal_id'] . '">Create this Goal.</a>'; }
		  ?></p>
		</div>
	  </div>
	<?php
	}
  ?>
  
<?php 
if (isset($_GET['goal_id'])) 
{
	// a goal has been selected to be created, 

	if(empty($_POST['submit']))
	{
		// but the details form hasn't been submitted yet
		$agoal = get_goal($_GET['goal_id']);
		
		
		if(!empty($agoal))
		{
?>
			<br /><h3>Create a Goal</h3>
			<form action="" method="post">
		  <p>Create the Goal - &quot;<?php echo $agoal['goal_string']; ?>&quot;</p>
		  <?php
		  	if(!empty($agoal['goal_metric']))
			{
		  ?>
		  		<p>Goal: <input name="goal_total" type="text" size="5">  
		 
		  <?php echo $agoal['goal_metric']; 
		  }
		  ?>
		  
		  </p>
    		<input type="submit" name="submit" value="Submit" id="Submit">
		</form>
<?php
		}
	}
	else
	{
		// the details form has been submitted
		add_user_goal($_GET['goal_id'], $fbuser, $_POST['goal_total'], null);
		
		$goal_url = "http://ah.imfit.com/show_user_goal.php?goal_id=" . $_GET['goal_id'] . "&fb_user_id=$fbuser";
//		echo $goal_url;
		
		$facebook->api('/me/imfitdemo:set', 'post',
			array('goal' => $goal_url ) );
		
		
		?>
		
  <script type="text/javascript">
  function postSetGoal()
  {
      FB.api(
        '/me/imfitdemo:cook',
        'post',
        { goal: 'http://ah.imfit.com/show_user_goal.php?fb_user_id=<?php echo $fbuser; ?>&goal_id=<?php echo $_GET['goal_id']; ?>' },
        function(response) {
           if (!response || response.error) {
              alert('Error occured');
           } else {
              alert('Set Goal post was successful! Action ID: ' + response.id);
           }
        });
  }
  </script>
		
		<div id="fb-root"></div>
  <script>
    window.fbAsyncInit = function() {
      FB.init({
        appId      : '[YOUR_APP_ID]', // App ID
        status     : true, // check login status
        cookie     : true, // enable cookies to allow the server to access the session
        xfbml      : true  // parse XFBML
      });
    };

    // Load the SDK Asynchronously
    (function(d){
      var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
      js = d.createElement('script'); js.id = id; js.async = true;
      js.src = "//connect.facebook.net/en_US/all.js";
      d.getElementsByTagName('head')[0].appendChild(js);
    }(document));
	
  </script>


  <!--fb:activity actions="[YOUR_APP_NAMESPACE]:cook"></fb:activity-->
		
		<p>The goal has been created.</p>
		
		<?php
		
	}
}
?>
<p><a href="/questionaire.php">Next</a></p>
<?php require_once($_SERVER['DOCUMENT_ROOT'] . "/core/footer.inc.php"); ?>
