<?php 
$page_title = "User Already Registered";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); ?>
<?php 	echo "!";
?>

<p>You are already registered. Click <a href="/profile.php">here</a> to go to your profile. </p>


<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>
