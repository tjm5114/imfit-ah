<?php 

$page_heading = 'weight loss support<br>is <i><b><font color="#FF0080">easy</font></b></i> as ...';
$page_title = "imFIT - Home";

include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 
?>

	<div class="steps">
		<div class="one">
		<font class="one">
		1<br>
		<font color="#000000" size=5><img src="http://www.vibm.org/images/sign_up.jpg" width="64px" height="64px" /> Sign Up Free</font>
		</font>
		</div>
	
		<div class="two">
		<font class="two">
		2<br>
		<font color="#000000" size=5>
		<img src="http://providencepersonaltrainingandfitness.com/wp-content/uploads/2011/05/Photo-Focus-on-Goal-Setting.jpg" width="64px" height="64px" /> Set Your Goals
		</font></font>
		</div>
	
		<div class="three">
		<font class="three">
		3<br>
		<font color="#000000" size=5>
		<img src="http://www.inkity.com/shirtdesigner/prints/clipArt1/CCC00449.png" width="80px" height="64px" /> Get Motivated
		<br>Lose Weight!
		</font></font>
		</font>
		</div>
	</div>

	

	</div>
		</div>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>
