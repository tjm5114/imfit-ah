<?php
// This is an example of config.php
$dbhost = 'k6lyow7xf5.database.windows.net,1433';
$dbuser = 'imfitdb';
$dbpass = 'Imfit12!';
$dbname = 'imfitdb';
?>
