<?php
// OPEN the Database
include($_SERVER['DOCUMENT_ROOT'] . "/core/dbconnect.inc.php");

//Start creating tables
try{
	$sql_cmd = "CREATE TABLE users
 (
 user_id         int identity not null,
 user_name       varchar(25),
 user_zip        int,
 user_gender     varchar(10),
 user_email      varchar(25),
 user_password   varchar(8),
 user_age        int,
 user_dob        date,
 user_fb_id      int,
 user_reg_date   date,
constraint users_pk primary key clustered (user_id asc)
 )";

	//echo $sql_cmd;
	
    $conn = new PDO( "sqlsrv:Server= $host ; Database = $db ", $user, $pwd);
    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    $conn->query($sql_cmd)  ;
}
catch(Exception $e)
{
//    die(print_r($e));
}

try
{
	$sql_cmd = "CREATE TABLE question
	(
	q_id             int,
	q_string         varchar(256)
	)";
	
    $conn = new PDO( "sqlsrv:Server= $host ; Database = $db ", $user, $pwd);
    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    $conn->query($sql_cmd)  ;
}
catch(Exception $e)
{
//    die(print_r($e));
}

try 
{
	$sql_cmd  = "CREATE TABLE goal
	(
	goal_id             int,
	goal_string         varchar(256),
	goal_metric         varchar(25),
	goal_total          int,
	goal_completed      int
	)";

    $conn = new PDO( "sqlsrv:Server= $host ; Database = $db ", $user, $pwd);
    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    $conn->query($sql_cmd)  ;
}
catch(Exception $e)
{
//    die(print_r($e));
}

try 
{
	$sql_cmd = "CREATE TABLE user_reponse
	(
	user_id            int,
	q_id               int,
	q_string           varchar(256),
	ans_string         varchar(256),
	date_of_response   date,
	)";
	
    $conn = new PDO( "sqlsrv:Server= $host ; Database = $db ", $user, $pwd);
    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    $conn->query($sql_cmd)  ;
}

catch(Exception $e)
{
//    die(print_r($e));
}

?>
