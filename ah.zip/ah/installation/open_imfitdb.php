<?php
$con = mysql_connect($dbhost, $dbuser, $dbpass)
or
die('Tried hard: Could not connect :( ' . mysql_error());
mysql_select_db($dbname, $con);
?>
