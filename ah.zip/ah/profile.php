<?php 
$page_title = "User Profile";
include($_SERVER['DOCUMENT_ROOT'] . '/core/header.inc.php'); 
?>

<?php $afbuser = get_fb_user($fbuser); ?>
<style type="text/css">
<!--
.button {
	background-color: #3399FF;
	padding: 2pt;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	border: 1pt solid #000000;
}
-->
</style>


<h1>Profile</h1>
<div id="personal_info">
<h2>Personal Information</h2>
<p>Name: <?php echo $afbuser['user_fname'] . ' ' . $afbuser['user_lname']; ?></p>
<p>Zip: <?php echo $afbuser['user_zip']; ?></p>
<p>Gender: <?php 
switch($afbuser['user_gender'])
{
	case "M": 
		echo "Male";
		break;
	case "F":
		echo "Female";
		break;
	default:
		echo "Undisclosed";
		break;
}; 
?></p>
<p>Email: <?php echo $afbuser['user_email']; ?></p>
<p>Age: <?php echo $afbuser['user_age']; ?></p>
<p>Birthday: <?php echo $afbuser['user_dob']; ?></p>
<p>	<a href="edit_profile.php">Edit Profile</a>
</p>
</div>
<div id="goals">
  <h2>Goals  </h2>
  <?php
  	include_once($_SERVER['DOCUMENT_ROOT'] . '/core/goals.inc.php'); 
  	$agoals = get_user_goals($fbuser); 

	foreach($agoals as $agoal)
	{
	?>
	  <div id="goal_box">
		<div id="goal_icon">
		  <img src="<?php echo $agoal['goal_icon_url']; ?>" />
		</div>
		<div id="goal_title">
		  <p><?php echo $agoal['goal_string']; ?></p>
		</div>
		<div id="goal_desc">
		  <p><?php echo (empty($agoal['goal_total'])) ? "" : (($agoal['goal_finished'] / $agoal['goal_total']) * 100) . "% complete"; ?></p>
		</div>
	  </div>
	<?php
	}
  ?>
  
  <p>Click <a href="/create_goal.php">here</a> for your goals.</p>
  
</div>

<?php include($_SERVER['DOCUMENT_ROOT'] . '/core/footer.inc.php'); ?>
